# ANSEL Technologies

Simple Node.js/Express app using Docker

- Please add your own SMTP info for it to work


## Install Dependencies

```bash
npm install 
```

## Run

```bash
node app or node app.js
```